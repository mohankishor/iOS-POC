//
//  NPViewController.h
//  NDTVPhotosAppR&D
//
//  Created by test on 04/10/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "NPPhotoShootViewController.h"

#import "QuartzCore/QuartzCore.h"

@interface NPViewController : UIViewController<UIActionSheetDelegate,UITextFieldDelegate>
{
    UITapGestureRecognizer *tapGesture;
    UIPinchGestureRecognizer *pinchGesture;
    UISwipeGestureRecognizer *swipeGesture;
    UIRotationGestureRecognizer *rotateGesture;
}
@property (weak, nonatomic) IBOutlet UIImageView *blackImageView;

@property (nonatomic) BOOL isCameraAvailable;

@property (nonatomic,strong) NPPhotoShootViewController *photoShootViewController;

@property (strong ,nonatomic) NSData *imageData;

@property (weak, nonatomic) IBOutlet UIView *tapPhotoView;

@property (weak, nonatomic) IBOutlet UITextField *posterTextField;
@property (weak, nonatomic) IBOutlet UIView *textFieldView;
@property (weak, nonatomic) IBOutlet UIView *posterTextView;
@property (weak, nonatomic) IBOutlet UILabel *posterTextLabel;

@end
